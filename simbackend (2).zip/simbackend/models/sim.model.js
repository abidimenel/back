import mongoose from 'mongoose';

const simSchema = new mongoose.Schema({
  serialNumber: {
    type: String,
    required: true,
    unique: true,
  },
  forfait: {
    type: String,
    required: true,
  },
  forfaitInternet: {
    type: String,
    required: true,
  },
  assignedDate: {
    type: Date,
    default: null,
  },
  assignedTo: {
    type: String,
    default: null,
  },
}, { timestamps: true });

const Sim = mongoose.model('Sim', simSchema);

export default Sim;
