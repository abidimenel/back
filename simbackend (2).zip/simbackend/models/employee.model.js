import mongoose from 'mongoose';

const employeeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  cin: {
    type: String,
    required: true,
    unique: true,
  },
  poste: {
    type: String,
    required: true,
  },
  service: {
    type: String,
    required: true,
  },
  forfait: {
    type: String,
    required: true,
  },
  forfaitInternet: {
    type: String,
    required: true,
  },
  serialNumber: {
    type: String,
    required: true,
    unique: true,
  },
  phoneNumber: {
    type: String,
    default: null,
  },
  dateAssigned: {
    type: Date,
    default: null,
  },
}, { timestamps: true });

const Employee = mongoose.model('Employee', employeeSchema);

export default Employee;
