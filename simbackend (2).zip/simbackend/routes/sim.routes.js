import express from 'express';
import { createSim, assignSim, getAllSims } from '../controllers/sim.controller.js';

const router = express.Router();

router.post('/', createSim); // Ajouter une nouvelle SIM
router.post('/assign', assignSim); // Attribuer une SIM
router.get('/', getAllSims); // Obtenir toutes les SIMs

export default router;
