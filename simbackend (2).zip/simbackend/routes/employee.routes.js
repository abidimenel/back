const express = require('express');
const router = express.Router();
const Employee = require('../models/Employee');

// Récupérer tous les employés
router.get('/', async (req, res) => {
  try {
    const employees = await Employee.find();
    res.json(employees);
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la récupération des employés' });
  }
});

// Ajouter un nouvel employé
router.post('/', async (req, res) => {
  const { nom, cin, poste, service, forfaitInternet } = req.body;
  try {
    const newEmployee = new Employee({ nom, cin, poste, service, forfaitInternet });
    await newEmployee.save();
    res.status(201).json(newEmployee);
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de l\'ajout de l\'employé' });
  }
});

// Attribuer un numéro à un employé
router.put('/assign-number/:id', async (req, res) => {
  const { id } = req.params;
  const { numTelephone } = req.body;

  try {
    const updatedEmployee = await Employee.findByIdAndUpdate(
      id,
      { numTelephone, dateAttribution: new Date() },
      { new: true }
    );

    if (!updatedEmployee) {
      return res.status(404).json({ error: 'Employé non trouvé' });
    }

    res.json(updatedEmployee);
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de l\'attribution du numéro' });
  }
});

module.exports = router;
