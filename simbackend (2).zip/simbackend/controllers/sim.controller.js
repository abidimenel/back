import Sim from '../models/sim.model.js';
import Employee from '../models/employee.model.js';

export const createSim = async (req, res) => {
  try {
    const { serialNumber, forfait, forfaitInternet } = req.body;
    const newSim = new Sim({ serialNumber, forfait, forfaitInternet });
    await newSim.save();
    res.status(201).json(newSim);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Autres fonctions pour assignSim, getAllSims...
